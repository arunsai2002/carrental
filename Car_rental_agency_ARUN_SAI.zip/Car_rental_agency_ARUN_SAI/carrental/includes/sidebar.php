<div class="profile_nav">
          <ul>
           
            
            <li><a href="vehical-details.php">My Booking</a></li>
            <li><a href="registration.php">Sign In</a></li>
            <li><a href="logout.php">Sign Out</a></li>
          </ul>
        </div>
      </div>