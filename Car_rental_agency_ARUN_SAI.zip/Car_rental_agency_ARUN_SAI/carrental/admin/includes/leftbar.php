<nav class="ts-sidebar">
	<ul>

		<li><a href="#"><i class="fa fa-car"></i> Vehicles</a>
			<ul>
				<li><a href="post-avehical.php">Post a Vehicle</a></li>
				<li><a href="manage-vehicles.php">Manage Vehicles</a></li>
			</ul>
		</li>

		<li><a href="manage-bookings.php"><i class="fa fa-sitemap"></i> Bookings</a></li>
		





	</ul>
</nav>