How to run Project
1. Download and Unzip the file on your local system.

Database Configuration:

Open phpmyadmin
Create Database carrental
Import database carrental.sql (available SQL File Folder inside zip package)

For User
Open Your browser put inside browser “http://localhost/Car_rental_agency_ARUN_SAI/carrental/login.php"
Login Details for user:
Username : arun
Password: arun

For Admin Panel
Open Your browser put inside browser “http://localhost/Car_rental_agency_ARUN_SAI/carrental/admin”
Login Details for admin :
Username: admin
Password: admin